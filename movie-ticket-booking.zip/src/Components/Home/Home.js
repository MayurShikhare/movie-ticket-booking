import React from 'react';
import Allmovies from './AllMovies/AllMovies';
import Filters from './Filters/Filters';
// import Navbar from './NabBar/NavBar';
import Slider from './Slider/Slider';

const Home = () => {
  return (
    <div>
      {/* <Navbar /> */}
      <Slider />
      <Filters />
      <Allmovies />
    </div>
  );
}

export default Home;
