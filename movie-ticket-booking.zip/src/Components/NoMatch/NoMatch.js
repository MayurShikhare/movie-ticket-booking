import React from 'react';

const Nomatch = () => {
  return (
    <div>
      <h1>No Match Found</h1>
    </div>
  );
}

export default Nomatch;
